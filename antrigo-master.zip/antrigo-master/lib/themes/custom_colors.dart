import 'package:flutter/material.dart';

const Color colorButton = Color(0xFF99AAB5); 
const Color colorHome = Color(0xFFF29EC7);
const Color colorButtonHome = Color(0xFFFFECF5);
const Color colorPinkText = Color(0xFFDD1D90);