package com.example.antrigo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
